# Racial/Ethnic Diversity Index: Deviation from US Average 
# Highlights:
# -coordinate transformation
# -diverging color palette from RColorBrewer
# -specify the number of classes
# -add legend histogram

install.packages("tmap")
install.packages("sf")
install.packages("dplyr")
install.packages("RColorBrewer")

library(tmap)
library(sf)
library(dplyr)
library(RColorBrewer)

# Set your working directory
setwd("~/Desktop/SCHOOL/Spring 2025/GEOG 4165 Data Visualization/W4/W4_Ex_Code_Data")

# Read the shapefile (including the .shp, .shx, and .dbf files, no need for the .xml)
counties <- st_read("data/CensusTracts2010.shp")

# Check the names of the columns in the shapefile to identify the diversity index
names(counties)

# Example: If you want to calculate deviation from the state average using a column like 'ETHHET_dev'
state_mean <- mean(counties$POP100, na.rm = TRUE)

# Create a new column for the deviation from the state average
counties <- counties %>%
  mutate(deviation_from_state = POP100 - state_mean)

# read geometries--------------------------------------------------
counties <- sf::st_read("data/CensusTracts2010.shp") %>%
  dplyr::select("GEOID10", "deviation_from_state")

# check Brewer's color palettes------------------------------------
RColorBrewer::display.brewer.all(colorblindFriendly = TRUE)

# produce the map--------------------------------------------------
map <- tmap::tm_shape(counties) +         # add counties layer
  tm_fill(                                #    specify counties symbology
    col = "deviation_from_state",         #       which attribute determines the color?
    palette="YlGnBu",                     #       color palette
    style = "quantile",                   #       class breaks method.
    n = 5,                                #       number of classes
#    legend.hist=T,                        #       legend histogram
    title = "Population Index: Deviation from State Average") +          #       title for legend item
  tm_borders() +                          #    add polygon borders
  
  tm_layout(                              # layout arguments
    frame = FALSE,                        #    hide map frame
    legend.outside = TRUE,                #    legend outside map frame    
    legend.format = list(digits = 2))   #    legend number format: two digits


# display the map--------------------------------------------------
map

# save the map-----------------------------------------------------
tmap_save(map, "figures/Population Index: Deviation from State Average.png")


# important resources----------------------------------------------
# r documentation: https://www.rdocumentation.org/
# tmap package documentation: https://www.rdocumentation.org/packages/tmap/versions/3.3-3 (check out for details on all tmap functions used here)
# sf package documentation: https://www.rdocumentation.org/packages/sf/versions/1.0-9

