# Population Density Salt Lake County Census Tracts 2020
# Highlights:
# -load shapefiles using the sf library
# -displaying Colorbrewer's palettes
# -using the tmap package to produce a map featuring sequential color scheme
# -adding an additional data layer to the map and legend

install.packages("tmap")
install.packages("sf")
install.packages("dplyr")
install.packages("RColorBrewer")

library(tmap)
library(sf)
library(dplyr)
library(RColorBrewer)

# set workspace
setwd("~/Desktop/SCHOOL/Spring 2025/GEOG 4165 Data Visualization/W4/W4_Ex_Code_Data")

#read geometries--------------------------------------------------
tracts <- sf::st_read("data/CensusTracts2010.shp") %>%
  base::subset(., select = c("NAME10","GEOID10","P0020006"))

roads <- st_read("data/USAFreeways.shp") %>%
  subset(., select = c())

county <- st_read("data/SLC.shp") %>%
  subset(., select = c())

#check Brewer's color palettes------------------------------------
RColorBrewer::display.brewer.all(colorblindFriendly = TRUE)

#produce the map--------------------------------------------------
map <- tmap::tm_shape(tracts) +                 # add tracts layer
  tm_fill(                                #    specify tracts symbology
    col = "P0020006",                     #       which attribute determines the color?
    palette="OrRd",                       #       color palette. for other choices, see ColorBrewer's palettes
    style = "quantile",                   #       class breaks method. other choices: "cat", "fixed", "sd", "equal", "pretty", "quantile", "kmeans", "hclust", "bclust", "fisher", "jenks", "dpih", "headtails", "log10_pretty"
    title = "Black Population Density 2010") +  #       title for legend item
  tm_borders() +                          #    add polygon borders
  
  tm_shape(roads) +                       # add roads layer
  tm_lines(                               # specify roads symbology
    col = "black",                        #    line color 
    scale = 3) +                          #    line width
  
  tm_layout(                              # layout arguments
    frame = FALSE,                        #    hide map frame
    legend.outside = TRUE,                #    legend outside map frame    
    legend.format = list(digits = 2)) +   #    legend number format: two digits
  
  tm_add_legend('line',                   # add roads legend item       
                col = "black",            #    color
                lwd = 3,                  #    line width
                labels = "Roads")         #    label

#display the map--------------------------------------------------
map

#save the map-----------------------------------------------------
tmap_save(map, "figures/black population density 2010.png")


#important resources----------------------------------------------
#r documentation: https://www.rdocumentation.org/
#tmap package documentation: https://www.rdocumentation.org/packages/tmap/versions/3.3-3 (check out for details on all tmap functions used here)
#sf package documentation: https://www.rdocumentation.org/packages/sf/versions/1.0-9

