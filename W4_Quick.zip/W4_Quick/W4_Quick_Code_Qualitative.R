# Healthcare Facilities in St. George
# Highlights:
# -use of tmap view mode
# -qualitative color palette from RColorBrewer
# -export to leaflet widget for browser integration 

# install packages-------------------------------------------------
# install.packages("tmap")
# install.packages("sf")
# install.packages("dplyr")
# install.packages("RColorBrewer")
# install.packages("pacman")

# load packages----------------------------------------------------
library(tmap)
library(sf)
library(dplyr)
library(RColorBrewer)
library(pacman)

# set workspace----------------------------------------------------
setwd("~/Desktop/SCHOOL/Spring 2025/GEOG 4165 Data Visualization/W4/W4_Ex_Code_Data")

# switch to view mode----------------------------------------------
current.mode <- tmap_mode("view")

# read geometries--------------------------------------------------
facilities <- st_read("data/Trailheads.shp") %>%
  subset(., select = c("Comments"))

# check Brewer's color palettes------------------------------------
display.brewer.all(colorblindFriendly = TRUE)

# check basemap providers------------------------------------------
leaflet::providers

# produce the map--------------------------------------------------
map <- tm_basemap(leaflet::providers$CartoDB.Positron) +
  tm_shape(
    facilities,
    bbox = "St. George, UT") + 
  tm_dots(
    col = "Comments",
    size = .5,
    palette = "Dark2")

# display the map in RStudio---------------------------------------
map

# create leaflet widget--------------------------------------------
lf_map <- tmap_leaflet(map)
p_load(htmlwidgets)
saveWidget(lf_map, file="figures/MainUseTrails.html")
